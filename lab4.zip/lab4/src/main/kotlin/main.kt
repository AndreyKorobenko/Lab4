import org.springframework.context.ApplicationContext
import org.springframework.context.annotation.AnnotationConfigApplicationContext

fun main() {
    val ctx: ApplicationContext =
        AnnotationConfigApplicationContext(ToDoConfig::class.java)

    var toDo: ToDo = ctx.getBean(ToDo::class.java)
    toDo.add(ToDoItem("Помыть посуду", Status.ACTIVE))
    toDo.add(ToDoItem("Убраться", Status.ACTIVE))
    toDo.add(ToDoItem("Погулять с собакой", Status.DONE))
    toDo.add(ToDoItem("Отдохнуть", Status.ACTIVE))

    toDo.print(toDo.listToDo())

    toDo.deleteDone()

    toDo.print(toDo.listToDo())
    while (true){
        println("1) add \n2) print \n3) find \n4) del \n5) exit")
        when(readLine()!!.toString()){
            "1" -> {
                println("Введите описание")
                toDo.add(ToDoItem(readLine()!!.toString(), Status.ACTIVE))
            }
            "2" -> {
                toDo.print(toDo.listToDo())
            }
            "3" -> {
                println("Введите описание")
                println(toDo.find(readLine()!!.toString()).toString())
            }
            "4" -> {
                println("Введите описание")
                toDo.delete(readLine()!!.toString())
            }
            "5" -> {
                break
            }
            else -> {continue}

        }
    }
}


