data class ToDoItem(var description: String, var status: Status){
    var twoLevel: List<ToDoItem> = listOf()
}

enum class Status{
    DONE,ACTIVE
}
